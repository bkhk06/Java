package com.adcc.rabbitmqdemo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Rabbitmqdemo2Application {

    public static void main(String[] args) {

        SpringApplication.run(Rabbitmqdemo2Application.class, args);
    }

}
