package com.cdm.started;

import org.tanukisoftware.wrapper.WrapperSimpleApp;
import org.tanukisoftware.wrapper.WrapperStartStopApp;

public class  SectorStatusServer  {

    public static void main(String[] args) {
        WrapperSimpleApp.main(args);
    }
}
