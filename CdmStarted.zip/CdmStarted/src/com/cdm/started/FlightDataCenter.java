package com.cdm.started;

import org.tanukisoftware.wrapper.WrapperStartStopApp;

public class FlightDataCenter {

    public static void main(String[] args) {
        WrapperStartStopApp.main(args);
    }
}
