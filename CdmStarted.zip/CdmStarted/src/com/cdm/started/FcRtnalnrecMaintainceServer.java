package com.cdm.started;

import org.tanukisoftware.wrapper.WrapperStartStopApp;

public class  FcRtnalnrecMaintainceServer  {

    public static void main(String[] args) {
        WrapperStartStopApp.main(args);
    }
}
