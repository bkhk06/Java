package com.cdm.started;

import org.tanukisoftware.wrapper.WrapperSimpleApp;
import org.tanukisoftware.wrapper.WrapperStartStopApp;

public class  SectorStatusZUUU  {

    public static void main(String[] args) {
        WrapperSimpleApp.main(args);
    }
}
