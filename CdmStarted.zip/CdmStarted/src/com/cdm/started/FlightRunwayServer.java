package com.cdm.started;

import org.tanukisoftware.wrapper.WrapperStartStopApp;

public class  FlightRunwayServer  {

    public static void main(String[] args) {
        WrapperStartStopApp.main(args);
    }
}
